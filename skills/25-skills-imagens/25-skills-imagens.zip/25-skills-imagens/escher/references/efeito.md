# Receita: /escher

## Critérios visuais

- Aplique a geometria impossível à arquitetura, aos caminhos ou a suportes do assunto.
- Crie pelo menos uma contradição espacial legível, como uma escada que retorna a si ou uma passagem entre planos incompatíveis.
- Mantenha cada trecho localmente convincente com oclusão, luz e escala consistentes.
- Preserve pessoas e objetos centrais reconhecíveis. Evite deformações aleatórias e trocar o assunto por uma escada genérica.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Transform the source setting into an Escher-inspired impossible construction. Integrate clearly readable spatial paradoxes such as a staircase returning to itself, connected incompatible planes or a passage that changes orientation. Make each local section convincing through consistent shading, occlusion and scale. Preserve the original central subjects and recognizable setting cues. Create deliberate impossible geometry rather than random warping or replacing the image with a generic staircase.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
