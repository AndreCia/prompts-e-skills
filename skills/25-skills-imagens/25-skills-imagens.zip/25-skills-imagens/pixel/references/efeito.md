# Receita: /pixel

## Critérios visuais

- Use uma grade de pixels consistente, silhuetas legíveis e uma paleta limitada adaptada à imagem.
- Desenhe agrupamentos de pixels com intenção. Reserve detalhes para rosto, contorno e elementos identificadores.
- Mantenha as bordas dos pixels nítidas, sem suavização ou mistura de resoluções aparentes.
- Evite aplicar apenas um filtro de mosaico e não acrescente interface de jogo.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Redraw the source image as deliberate high-quality pixel art with a consistent pixel grid, readable silhouettes, carefully designed pixel clusters and a restrained palette adapted to the original. Preserve the composition, subject identities and defining details. Keep pixel edges crisp without antialiasing or mixed pixel scales. This should look hand-designed rather than a mosaic filter, and should not include a game interface.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
