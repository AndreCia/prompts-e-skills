# Receita: /lego

## Critérios visuais

- Reconstrua o assunto e o cenário com blocos encaixados. Mostre pinos, juntas, placas e bordas de plástico.
- Converta pessoas em minifiguras e animais em construções reconhecíveis. Preserve pose, roupas, cores e distribuição dos elementos.
- Use peças menores para detalhes que definem a identidade do assunto, sem perder a silhueta.
- Evite superfícies fotográficas intactas no cenário convertido e não acrescente logotipos ou embalagens.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Rebuild the complete source scene as a detailed LEGO construction. Make every major subject and environmental element from interlocking plastic bricks, plates and tiles with visible studs and seams. Represent people as recognizable minifigures while preserving their pose, clothing colors and placement. Use smaller pieces for distinctive subject details. Preserve the composition and lighting direction. The result should read as a physically buildable brick scene, without added logos or packaging.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
