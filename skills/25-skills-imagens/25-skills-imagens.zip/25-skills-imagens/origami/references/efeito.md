# Receita: /origami

## Critérios visuais

- Construa os elementos como volumes de papel dobrado, com vincos e abas que expliquem suas formas.
- Mantenha a silhueta e as cores características com dobras plausíveis e faces de papel.
- Mostre bordas, espessura discreta e pequenas variações de fibra. Use luz que evidencie os planos.
- Evite confundir origami com recortes empilhados, polígonos de plástico ou modelos impressos em 3D.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Recreate the source subjects and environment as sculptural folded-paper origami. Use credible folds, creases, tabs and planar paper surfaces to convey each recognizable silhouette. Preserve the original colors, arrangement and defining subject features. Show fine paper fibers and thin edges with lighting that reveals the folds. Avoid layered paper-cut collages and plastic polygon models.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
