# Receita: /hq

## Critérios visuais

- Use contornos de tinta, variação de espessura, retículas e sombras gráficas.
- Por padrão, faça um quadro principal com margem de página para preservar a cena. Use múltiplos quadros se o pedido definir sequência.
- Preserve personagens, ação e elementos que identificam a imagem, com enquadramento dramático compatível.
- Não invente falas, legendas ou enredo. Se houver texto solicitado, reproduza-o exatamente em português brasileiro.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Recreate the source scene as a dramatic comic-book page with one main panel, a clean page margin, expressive ink contours, varied line weight, halftone dots and graphic shadows. Preserve the identities, poses, action and key objects from the original. Keep the composition recognizable while using strong comic framing. Do not invent dialogue, captions or a new story; render any explicitly requested text exactly as supplied.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
