# Receita: /gigante

## Critérios visuais

- Torne o assunto principal monumental, mantendo sua forma, pose e identidade.
- Use referências de escala compatíveis com o contexto, como pessoas pequenas, prédios ou veículos.
- Ajuste perspectiva, contato com o solo, oclusão e sombras para sustentar a diferença de tamanho.
- Evite apenas ampliar e recortar o assunto ou adicionar destruição que não foi solicitada.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Make the main source subject monumental in scale while preserving its recognizable shape, identity and pose. Use context-appropriate tiny people, buildings or vehicles to establish the size difference. Integrate the giant subject through coherent perspective, ground contact, occlusion and cast shadows, maintaining recognizable cues from the original setting. Do not merely enlarge and crop the subject, and do not add unrequested destruction.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
