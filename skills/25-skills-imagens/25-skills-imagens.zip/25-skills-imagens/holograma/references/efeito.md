# Receita: /holograma

## Critérios visuais

- Converta o assunto principal em uma projeção luminosa semitransparente, mantendo sua silhueta e detalhes identificadores.
- Use linhas de varredura, emissão ciano ou azul e poucas falhas de transmissão controladas.
- Faça a luz da projeção interagir com superfícies próximas. Preserve o cenário como referência espacial.
- Evite tratar o efeito como simples contorno neon, fumaça ou remoção integral do fundo.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Turn the main source subject into a semi-transparent luminous holographic projection while keeping its silhouette, pose and identifying details. Use controlled cyan-blue emission, fine scan lines, subtle transmission gaps and visible internal light structure. Let the hologram cast a restrained glow on nearby surfaces and retain the surrounding setting for spatial context. Avoid a simple neon outline, heavy smoke or replacing the entire environment.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
