# Receita: /submerso

## Critérios visuais

- Converta o ambiente em uma cena completamente submersa, mantendo o assunto e a organização reconhecíveis.
- Use absorção de cor, luz filtrada, cáusticas, partículas e bolhas em escala coerente.
- Faça cabelo, roupas e elementos leves responderem à correnteza quando estiverem presentes.
- Evite apenas aplicar um filtro azul, adicionar peixes sem necessidade ou trocar o cenário original por um oceano genérico.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Place the complete source scene underwater while preserving the main subject identity, pose and recognizable environment layout. Add physically coherent color absorption, filtered overhead light, caustic patterns, suspended particles and a restrained number of bubbles. Let existing hair, fabric and lightweight objects respond naturally to the current. Maintain depth and realistic underwater visibility. Do not rely on a blue color filter alone or replace the setting with a generic ocean full of unrequested fish.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
