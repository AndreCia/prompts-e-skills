# Receita: /massinha

## Critérios visuais

- Modele toda a cena em massinha, incluindo personagens, objetos e cenário.
- Mostre pequenas marcas de dedos, junções, irregularidades e acabamento fosco artesanal.
- Preserve expressão, pose e traços identificadores. Simplifique detalhes sem produzir rostos genéricos.
- Use iluminação de um pequeno cenário de stop motion. Evite aparência de plástico liso ou textura de barro rachado.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Transform the entire source scene into handcrafted modeling-clay sculptures photographed on a stop-motion set. Use matte clay, subtle fingerprints, hand-shaped edges, small joins and gentle irregularities. Preserve the subject identity, expression, pose, dominant colors and scene arrangement. Model the background in clay as well. Keep the image tactile and carefully crafted, rather than glossy plastic or cracked pottery.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
