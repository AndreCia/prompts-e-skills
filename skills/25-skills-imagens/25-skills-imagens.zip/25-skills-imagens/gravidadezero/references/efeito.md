# Receita: /gravidadezero

## Critérios visuais

- Suspenda os elementos móveis já presentes na cena, preservando sua identidade e relações espaciais.
- Use pequenas rotações, afastamento dos apoios e sombras deslocadas para comunicar flutuação.
- Quando houver líquidos, forme gotas e volumes suspensos compatíveis com a situação.
- Preserve arquitetura e cenário como referência. Evite fragmentar o assunto em peças de montagem ou adicionar objetos aleatórios.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Make the movable elements already present in the source scene float in zero gravity. Preserve their identities and spatial relationships, introduce subtle rotations and separation from supporting surfaces, and use displaced shadows to communicate suspension. If liquids are present, shape them into floating droplets and cohesive volumes. Retain the architecture and setting as a spatial anchor. Do not dismantle objects into assembly parts or add unrelated floating props.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
