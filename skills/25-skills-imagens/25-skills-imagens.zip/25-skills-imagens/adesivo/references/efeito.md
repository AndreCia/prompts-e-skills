# Receita: /adesivo

## Critérios visuais

- Recorte o assunto principal completo, mantendo partes importantes e detalhes identificadores.
- Crie uma borda branca uniforme e um acabamento de adesivo de vinil. Preserve áreas vazadas quando fizerem parte do contorno.
- O fundo externo deve ter transparência real, com canal alfa. Use transparent_background=true na geração.
- Evite fundo quadriculado desenhado, retângulo branco, bordas cortadas e sombra grande que dificulte o recorte.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Create a clean die-cut vinyl sticker of the complete main source subject, preserving its identity, characteristic colors and important details. Isolate it with a consistent white cutline border, restrained vinyl sheen and neatly finished contours, retaining meaningful cutout openings. Leave generous transparent space around all edges. The external background must be genuinely transparent with an alpha channel, not a checkerboard illustration or a white rectangular card. Do not crop the sticker border.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.

Confira o canal alfa da saída PNG quando o arquivo estiver disponível. Um fundo quadriculado desenhado não atende ao pedido de transparência.
