# Receita: /fliperama

## Critérios visuais

- Adapte o assunto a um personagem, veículo ou elemento jogável de arcade, conforme a imagem.
- Construa um cenário de jogo legível inspirado no original, com perspectiva de plataforma, luta ou corrida compatível.
- Inclua uma interface pequena e coerente. Para rótulos padrão, use somente VIDA e PONTOS, com números simples.
- Mantenha o personagem reconhecível e diferencie o efeito de pixel art sem interface. Não coloque o resultado dentro de uma máquina física sem pedido.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Transform the source image into a playable-looking arcade game screenshot. Adapt the original subject into the appropriate playable character, vehicle or game element, and rebuild a readable game stage inspired by the original setting. Choose a coherent platform, fighting or racing perspective based on the subject. Add a restrained arcade HUD using only the exact labels "VIDA" and "PONTOS" with simple numbers. Preserve recognizable subject features. Show the game scene itself, not a physical arcade cabinet.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
