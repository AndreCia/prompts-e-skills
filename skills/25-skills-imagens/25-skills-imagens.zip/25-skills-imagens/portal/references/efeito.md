# Receita: /portal

## Critérios visuais

- Apresente a cena original dentro de uma moldura, tela ou fotografia coerente com o contexto.
- Faça parte do assunto cruzar fisicamente a borda e avançar para o espaço externo.
- Mostre oclusão na borda, espessura da moldura e sombras projetadas para comunicar a passagem entre planos.
- Preserve identidade, continuidade corporal e escala. Evite apenas um anel luminoso ou colagem sem profundidade.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Present the source scene inside a coherent picture frame, screen or photograph, then make part of the main subject physically emerge beyond its border into the space in front. Preserve the subject identity, pose and continuous geometry across the boundary. Use frame thickness, edge occlusion, cast shadows and perspective to create convincing depth between the image plane and external space. The effect must read as breaking through the frame, not simply a glowing portal ring or flat collage.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
