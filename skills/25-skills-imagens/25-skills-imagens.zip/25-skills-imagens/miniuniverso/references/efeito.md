# Receita: /miniuniverso

## Critérios visuais

- Use a própria forma do assunto como território ou estrutura de um mundo em miniatura.
- Integre construções, caminhos, pontes e habitantes pequenos aos contornos e às superfícies existentes.
- Preserve a silhueta e os detalhes que permitem reconhecer o assunto original.
- Mantenha escala e acesso coerentes. Evite apenas colocar uma cidade atrás do assunto ou fazer um diorama sobre uma base separada.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Turn the main source subject itself into a tiny inhabited world. Integrate miniature buildings, paths, bridges and small residents directly into its existing contours and surfaces, treating its shape as terrain or architecture. Preserve the original silhouette and identifying details so the source subject remains immediately recognizable. Maintain coherent miniature scale and connected routes. Do not merely place a town behind the subject or move the scene onto an unrelated diorama base.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
