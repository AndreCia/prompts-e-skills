# Receita: /blueprint

## Critérios visuais

- Use linhas técnicas claras sobre fundo azul, com uma vista principal fiel à silhueta do assunto.
- Acrescente vistas auxiliares e detalhes ampliados que ajudem a compreender sua construção.
- Use linhas de referência, eixos e indicações de montagem. Inclua medidas numéricas somente quando forem fornecidas pelo usuário.
- Para objetos sem medidas ou estrutura verificadas, produza um estudo visual conceitual. Não apresente números ou mecanismos inventados como especificações reais.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Convert the source subject into a precise-looking conceptual blueprint with clean light technical lines on a deep blue background. Preserve its recognizable silhouette in the main view and add useful auxiliary views, enlarged construction details, centerlines and assembly callouts. Use dimension guides without invented numeric measurements; include exact measurements only when supplied by the user. Keep the diagram internally consistent and visually legible, without claiming verified engineering specifications.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
