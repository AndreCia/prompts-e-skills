# Receita: /cartoon

## Critérios visuais

- Use formas simplificadas, volumes arredondados e acabamento de animação 3D de longa-metragem.
- Preserve identidade, expressão, pose, penteado e roupas. Ajuste proporções com moderação.
- Crie iluminação cinematográfica e materiais estilizados com profundidade e contato coerentes.
- Evite nomes de estúdios, personagens existentes e conversão em desenho plano.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Transform the source image into a polished 3D animated-film scene. Use expressive stylized characters, clean rounded volumes, appealing proportions and carefully lit dimensional materials. Preserve each subject identity, pose, expression, hairstyle, clothing and placement. Carry the stylization through the environment while retaining the original composition and dominant colors. Avoid copying existing animated characters or flattening the result into a two-dimensional drawing.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
