# Receita: /derreter

## Critérios visuais

- Deforme partes selecionadas do assunto em escorrimentos, dobras e gotas que conservem pistas da forma original.
- Mantenha uma região estável e reconhecível para contrastar com o derretimento.
- Faça gravidade, viscosidade, contato com superfícies e reflexos responderem ao material original.
- Evite borrão, destruição completa e deformação facial que apague a identidade.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Create a surreal melting transformation of selected parts of the source subject. Stretch and soften its original materials into convincing drips, folds and pooled shapes while retaining a stable recognizable region and defining identity cues. Respect gravity, material viscosity, surface contact and reflections. Preserve the source setting and composition. Make the deformation deliberate and readable rather than a blur, total destruction or identity-erasing facial distortion.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
