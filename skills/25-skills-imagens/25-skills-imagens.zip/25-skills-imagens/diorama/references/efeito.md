# Receita: /diorama

## Critérios visuais

- Reconstrua a cena inteira como um modelo físico em miniatura, sobre uma base visível.
- Mostre materiais de maquete, pequenas imperfeições e detalhes em escala consistente.
- Fotografe a miniatura com profundidade de campo curta sem apagar os detalhes que identificam o assunto.
- Evite apenas desfocar a foto original. A base, os volumes e os materiais precisam comunicar uma miniatura física.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Recreate the complete source scene as a carefully crafted physical miniature diorama on a visible display base. Preserve the original arrangement and defining subject details using consistent miniature scale, model-making materials and subtle handmade imperfections. Photograph the model with realistic shallow depth of field and convincing studio light while keeping the main subject readable. The miniature must be evident through its base, construction and materials, not just a blur filter.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
