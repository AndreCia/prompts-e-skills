# Receita: /papercut

## Critérios visuais

- Separe fundo, planos intermediários e assunto em camadas físicas de papel recortado.
- Crie profundidade com afastamento, oclusão e sombras reais entre as camadas.
- Preserve as silhuetas, a hierarquia visual e a paleta, com bordas limpas e fibras discretas.
- Evite volumes de origami, papel amassado e sombras incompatíveis com a direção da luz.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Convert the source composition into a layered paper-cut artwork. Separate the backdrop, intermediate planes and foreground subject into precisely cut colored cardstock layers. Create convincing depth through spacing, occlusion and cast shadows between layers. Preserve the original silhouettes, visual hierarchy and color palette. Show crisp cut edges and subtle paper fibers, without folded origami volumes.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
