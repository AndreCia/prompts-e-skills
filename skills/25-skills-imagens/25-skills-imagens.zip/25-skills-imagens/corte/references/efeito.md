# Receita: /corte

## Critérios visuais

- Remova uma seção delimitada do assunto, com um plano de corte e espessura de material visíveis.
- Preserve a maior parte da superfície externa para manter o objeto reconhecível.
- Mostre camadas, cavidades e componentes compatíveis com o tipo de assunto. Use oclusão e sombras para distinguir interior de exterior.
- Evite transparência radiográfica e explosão de peças. Para seres vivos, use representação didática sem violência explícita.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Create a clear cutaway cross-section of the source subject by removing one bounded section. Keep most of the exterior intact and recognizable, show a definite cut plane and material thickness, and reveal plausible interior layers, cavities and components appropriate to the subject. Use realistic occlusion, contact shadows and shading to distinguish inside from outside. This is a cutaway illustration, not an X-ray or an exploded assembly. For living subjects, use a non-graphic educational model.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
