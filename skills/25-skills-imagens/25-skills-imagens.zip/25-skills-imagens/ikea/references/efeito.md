# Receita: /ikea

## Critérios visuais

- Escolha um conjunto desmontável do assunto principal, como uma lente, roda ou painel. Preserve o restante montado e reconhecível.
- Separe de quatro a sete componentes ao longo de um eixo de montagem coerente. Mostre encaixes correspondentes, anéis, fixações e pequenos parafusos.
- Use setas finas, linhas de alinhamento e números discretos para comunicar como as peças voltariam ao lugar. Evite peças sem relação com o objeto.
- Se usar números, associe cada número a uma única peça, em sequência e sem repetição. Deixe o corpo montado sem número. Confira as marcações na imagem gerada.
- Mantenha materiais, iluminação e cenário da foto. Aumente o espaço entre peças quando necessário, sem cortar componentes na borda.
- O resultado é uma interpretação visual de montagem. Não invente instruções mecânicas verificadas nem acrescente o logotipo IKEA.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Create an IKEA-inspired partial exploded assembly view of the main subject. Keep most of the subject assembled and recognizable. Select one coherent detachable assembly and separate four to seven related components along its assembly axis, with matching joints, a few aligned screws, thin assembly arrows and discreet numeric callouts. Preserve the source materials, lighting and setting. Make the connections visually understandable, with sufficient spacing and no clipped parts. Do not turn the whole photograph into a furniture catalog or add an IKEA logo.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
