# Receita: /raiox

## Critérios visuais

- Mantenha a silhueta e a pose do assunto, com superfícies externas translúcidas e estruturas internas legíveis.
- Adapte o interior ao tipo de assunto: estrutura óssea simplificada, componentes mecânicos ou elementos construtivos.
- Use contraste radiográfico e sobreposição de densidades. Evite fazer uma abertura física na superfície.
- Trate o interior inferido como interpretação artística, sem diagnóstico, medições ou alegação de exame real.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Transform the source subject into an artistic X-ray visualization. Preserve its external silhouette, pose and framing while making outer surfaces translucent and revealing internally consistent structures suited to the subject: simplified skeleton, mechanical components or construction supports. Use radiographic contrast and overlapping densities with readable internal layers. Do not cut a physical opening in the surface, and do not add diagnoses, measurements or claims that this is a real scan.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
