---
name: abandonado
description: "Edite uma imagem com GPT Imagens: Mostra como a cena ficaria após décadas de abandono, com desgaste, vegetação e sinais da passagem do tempo. Use em pedidos de edição com /abandonado, $abandonado ou o efeito Décadas de abandono."
---

# /abandonado: Décadas de abandono

Mostra como a cena ficaria após décadas de abandono, com desgaste, vegetação e sinais da passagem do tempo.

## Entrada e ativação

Use `$abandonado` para invocação nativa no Codex. Reconheça também `/abandonado` quando escrito em um pedido de edição de imagem. O atalho textual não instala um comando de barra na interface de outros aplicativos.

Use a imagem anexada, o caminho indicado ou a imagem pertinente mais recente como alvo da edição. Se não houver imagem, peça o arquivo; não substitua por uma imagem inventada. Se houver vários alvos indistinguíveis, peça somente a escolha do alvo. Modificadores do usuário, como região, intensidade, proporção e elementos a preservar, prevalecem sobre os padrões desta Skill.

## Execução

1. Inspecione a imagem. Para arquivo local, use `view_image` antes da edição. Identifique assunto, pose, silhueta, cores e composição que precisam continuar reconhecíveis.
2. Leia [a receita do efeito](references/efeito.md). Aplique seus critérios ao assunto observado, em vez de usar um exemplo genérico no lugar da imagem.
3. Monte um prompt de edição com a imagem-alvo, a transformação, as partes preservadas e os modificadores do usuário. Use o modelo de prompt da referência como ponto de partida. Preserve a proporção original por padrão; adapte o enquadramento apenas quando o efeito exigir espaço.
4. Execute a edição com a ferramenta integrada `image_gen.imagegen`, usando a imagem original como entrada. Se todos os alvos tiverem caminhos locais, use `referenced_image_paths` depois de inspecioná-los. Caso contrário, use `num_last_images_to_include` com o menor número que inclua os alvos, até cinco. Não combine esses dois mecanismos. Preserve transparência existente. Para uma foto com fundo opaco, use `transparent_background=false`.
5. Não substitua a edição por um prompt entregue ao usuário. Se a ferramenta estiver indisponível, informe a limitação. Não mude para API paga, instale dependências nem solicite chave para uma edição pela ferramenta integrada.
6. Mostre a imagem e inspecione o resultado. Confira os critérios da referência, a identidade do assunto, a composição e a ausência de partes cortadas involuntariamente. Corrija uma falha concreta com uma revisão direcionada; não gere variações extras sem motivo.
7. Preserve o arquivo original. Quando houver entrega de arquivo no projeto, copie a saída gerada para `output/gpt-imagens/abandonado/` ou para o destino pedido, com nome novo. Mostre a imagem e forneça um link para a saída salva. Informe somente verificações que realmente executou.

Não acrescente slogans, marcas, falas ou legendas fora dos elementos definidos na receita ou solicitados pelo usuário. Quando houver texto solicitado na imagem, mantenha-o exatamente no idioma e na grafia fornecidos. Use português brasileiro com acentuação correta nas respostas.
