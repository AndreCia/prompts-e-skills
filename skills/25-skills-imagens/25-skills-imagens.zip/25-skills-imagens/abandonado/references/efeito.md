# Receita: /abandonado

## Critérios visuais

- Envelheça o cenário e os objetos de acordo com seus materiais e a exposição: poeira, oxidação, pintura descascada ou madeira desgastada.
- Integre vegetação quando houver acesso plausível a luz e umidade. Preserve a estrutura reconhecível.
- Mantenha o ponto de vista, a disposição dos elementos e as principais cores como pistas da cena original.
- Preserve a identidade de pessoas presentes. Não acrescente cadáveres, violência ou ruína integral sem pedido.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Show the source scene after decades of abandonment. Preserve its recognizable architecture, objects, viewpoint and arrangement while applying material-specific aging: accumulated dust, oxidation, peeling paint, weathered wood and credible deterioration. Introduce vegetation only where access to light and moisture makes sense. Keep existing people recognizable rather than replacing them or inventing a violent story. Communicate elapsed time through coherent environmental wear, without total destruction unless requested.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
