# Receita: /biomecanico

## Critérios visuais

- Mantenha a forma e a identidade do assunto, integrando mecanismos à sua estrutura.
- Faça engrenagens, cabos e articulações seguirem funções e direções plausíveis, com transições graduais entre materiais.
- Equilibre componentes orgânicos e mecânicos. Preserve pose e movimento, sem ocultar o rosto quando houver.
- Evite adesivos de engrenagens na superfície, armadura genérica e ferimentos ou cirurgia gráfica.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Fuse the source subject with integrated biomechanical structures while preserving its recognizable form, identity and pose. Blend organic shapes with functional-looking gears, cables, actuators and articulated joints, following plausible load paths and movement directions. Create convincing transitions between materials rather than attaching random gear decorations. Balance organic and mechanical elements, keep faces recognizable when present, and avoid graphic injuries or generic armor replacing the subject.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
