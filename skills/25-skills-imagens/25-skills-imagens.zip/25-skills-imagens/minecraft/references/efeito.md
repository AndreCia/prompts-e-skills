# Receita: /minecraft

## Critérios visuais

- Converta a cena em volumes cúbicos e texturas de baixa resolução próprias de um mundo de Minecraft.
- Modele personagens com cabeças cúbicas e membros retangulares, mantendo roupas, pose e cores reconhecíveis.
- Transforme terreno, arquitetura e vegetação em blocos, preservando a composição.
- Evite pinos de LEGO e pixel art plana. Não adicione personagens, interface ou inimigos sem necessidade.

## Modelo de prompt

Adapte a descrição ao que foi observado na imagem. Os campos entre colchetes são preenchidos antes da geração. Preserve textos pedidos pelo usuário em sua grafia original.

```text
Use case: style-transfer
Input image: edit target, not merely a style reference.
Observed subject and composition: [describe the actual image].
Transformation: Rebuild the source image as a recognizable Minecraft world using cubic voxel geometry and low-resolution block textures. Convert people into block-shaped characters with cubic heads and rectangular limbs, preserving their clothing colors, poses and distinguishing features. Reconstruct terrain, architecture and vegetation from blocks while retaining the original scene arrangement and lighting mood. Do not use LEGO studs, flat pixel art or unrequested game characters and interface.
Preserve: [identity cues, pose, composition, colors and elements that this effect does not change].
User modifiers: [apply requested region, intensity and other constraints, or omit this line].
Output: one edited image; preserve source aspect ratio unless the requested effect needs more room.
```

## Conferência

Verifique se a transformação acima aparece claramente e se o assunto de origem continua reconhecível. Diferencie preservação de identidade de preservação literal dos materiais: materiais e geometria podem mudar conforme o efeito.
